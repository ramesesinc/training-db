#!/bin/sh

mysql -u root -p1234 -f < zzz_etracs255.sql && \
mysql -u root -p1234 -f < zzz_image.sql && \
mysql -u root -p1234 -f < zzz_notification.sql
